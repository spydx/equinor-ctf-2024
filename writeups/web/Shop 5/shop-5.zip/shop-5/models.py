import os
from typing import Optional

from sqlalchemy import func
from sqlmodel import Column, Field, Session, SQLModel, String, Text, select


class Order(SQLModel, table=True):
    __tablename__ = "orders"
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int = Field(foreign_key="users.id")
    item_id: int = Field(foreign_key="items.id")


class User(SQLModel, table=True):
    __tablename__ = "users"
    id: Optional[int] = Field(default=None, primary_key=True)
    username: str = Field(sa_column=Column(String(80), unique=True, nullable=False))
    password: str = Field(sa_column=Column(String(120), nullable=False))
    token: str = Field(sa_column=Column(String(120), nullable=False))
    balance: float = Field(default=100.00, nullable=False)


class Item(SQLModel, table=True):
    __tablename__ = "items"
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(sa_column=Column(String(100), nullable=False))
    description: str = Field(sa_column=Column(Text, nullable=False))
    price: float = Field(nullable=False)
    image: str = Field(sa_column=Column(String(100), nullable=False))
    rating: float = Field(nullable=False)
    in_stock: bool = Field(default=True, nullable=False)
    note: Optional[str] = Field(sa_column=Column(Text, nullable=True))


def init_db(session: Session):
    init_items = [
        Item(name="Fun", description="Our most fun item yet!", price=99.99, image="fun.png", rating=4.8, note="Here you go, you are now having fun!", in_stock=True),
        Item(
            name="EPT Fidget Toy",
            description="Stuck on another challenge? Try fidgeting with the new EPT fidget toy to keep your hands busy while your brain churns!",
            price=2499.99,
            image="fidget.png",
            rating=5.0,
            note="Come over to the admin booth and claim your very own EPT Fidget Toy for you and your team! " + os.environ.get("FLAG", "flag{fake-flag}"),
            in_stock=True,
        ),
        Item(name="Laptop", description="Powerful laptop for work and gaming", price=999.99, image="laptop.png", rating=4.5, in_stock=False),
        Item(name="Smartphone", description="Latest smartphone with advanced features", price=699.99, image="smartphone.png", rating=4.2, in_stock=False),
        Item(name="Headphones", description="Noise-cancelling headphones for immersive audio", price=249.99, image="headphones.png", rating=4.7, in_stock=False),
        Item(name="Smartwatch", description="Fitness tracker and smartwatch in one", price=199.99, image="smartwatch.png", rating=4.0, in_stock=False),
        Item(name="Camera", description="Professional-grade camera for stunning photos", price=1499.99, image="camera.png", rating=4.8, in_stock=False),
    ]

    items_count = session.exec(select(func.count(Item.id))).one_or_none()
    if items_count == len(init_items):
        return
    if items_count == 0:
        print("No items in database, adding initial items...")
        session.add_all(init_items)
        session.commit()
        print(f"Added {len(init_items)} initial items added successfully!")
    else:
        print(f"Unknown number of items in database {items_count=!r}")
        exit(1)
