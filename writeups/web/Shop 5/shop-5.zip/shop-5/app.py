import secrets
from contextlib import asynccontextmanager
from typing import Annotated, Generator

import bcrypt
from fastapi import Depends, FastAPI, Form, Request, HTTPException
from fastapi.params import Query
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from models import Item, Order, User, init_db
from sqlalchemy import func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import sessionmaker
from sqlmodel import Session, SQLModel, create_engine
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException


def get_session() -> Generator[Session, None, None]:
    with Session(engine) as session:
        yield session


@asynccontextmanager
async def lifespan(app: FastAPI):
    SQLModel.metadata.create_all(engine)
    with Session(engine) as session:
        init_db(session)
    yield


app = FastAPI(lifespan=lifespan)

engine = create_engine("sqlite:///shop.db", connect_args={"check_same_thread": False})

async_session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")


SessionDep = Annotated[Session, Depends(get_session)]


def get_user(request: Request, session: Session) -> tuple[User | None, int]:
    token = request.cookies.get("token")
    if not token:
        return None, 0

    result = session.exec(select(User, func.count(Order.id).label("order_count")).outerjoin(Order, User.id == Order.user_id).filter(User.token == token).group_by(User.id)).first()

    if result:
        user, order_count = result
        return user, order_count
    else:
        return None, 0


@app.get("/", response_class=HTMLResponse)
async def index(request: Request, session: SessionDep, error: str = "", success: str = ""):
    items = session.exec(select(Item)).scalars().all()
    user, order_count = get_user(request, session)
    if user:
        user_orders = session.exec(select(Order.item_id, func.count(Order.id).label("order_count")).filter(Order.user_id == user.id).group_by(Order.item_id)).all()
        orders = {row.item_id: row.order_count for row in user_orders}
    else:
        orders = {}
    return templates.TemplateResponse("index.html", {"request": request, "user": user, "order_count": order_count, "items": items, "orders": orders, "error": error, "success": success})


@app.post("/")
async def buy(request: Request, session: SessionDep, item_id: int = Form(...)):
    user, _ = get_user(request, session)
    if not user:
        return RedirectResponse(url="/login?error=Please log in to make a purchase", status_code=303)

    item = session.get(Item, item_id)
    if not item:
        return await index(request, error="Item not found", session=session)

    if user.balance < item.price:
        return await index(request, error="Insufficient balance", session=session)

    user.balance -= item.price
    order = Order(user_id=user.id, item_id=item.id)
    session.add(order)
    session.commit()
    return await index(request, success=f"Successfully purchased {item.name}", session=session)


@app.get("/register", response_class=HTMLResponse)
async def register_page(request: Request, session: SessionDep):
    user, order_count = get_user(request, session)
    return templates.TemplateResponse("register.html", {"title": "Register", "request": request, "user": user, "order_count": order_count})


@app.post("/register")
async def register(request: Request, session: SessionDep, username: str = Form(...), password: str = Form(...), confirm_password: str = Form(...)):
    if password != confirm_password:
        return templates.TemplateResponse("register.html", {"title": "Register", "request": request, "error": "Passwords do not match"}, status_code=400)

    existing_user = session.exec(select(User).filter_by(username=username)).scalar_one_or_none()
    if existing_user:
        return templates.TemplateResponse("register.html", {"title": "Register", "request": request, "error": "Username already exists"}, status_code=400)

    hashed_password = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
    new_user = User(username=username, password=hashed_password, balance=100.00, token=secrets.token_hex(16))
    session.add(new_user)
    session.commit()
    return RedirectResponse(url="/login?success=Registration successful. Please login.", status_code=303)


@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request, session: SessionDep, success: str = Query(default=None), error: str = Query(default=None)):
    user, order_count = get_user(request, session)
    return templates.TemplateResponse("login.html", {"title": "Login", "request": request, "user": user, "order_count": order_count, "success": success, "error": error})


@app.post("/login")
async def login(request: Request, session: SessionDep, username: str = Form(...), password: str = Form(...)):
    user = session.exec(select(User).filter_by(username=username)).scalar_one_or_none()
    if not user or not bcrypt.checkpw(password.encode("utf-8"), user.password.encode("utf-8")):
        return templates.TemplateResponse("login.html", {"title": "Login", "request": request, "error": "Incorrect username or password"}, status_code=400)
    response = RedirectResponse(url="/", status_code=303)
    response.set_cookie("token", user.token)
    return response


@app.get("/logout")
async def logout(request: Request):
    response = RedirectResponse(url="/")
    response.delete_cookie("token")
    return response


@app.get("/orders", response_class=HTMLResponse)
async def orders(request: Request, session: SessionDep, error: str = "", success: str = ""):
    user, order_count = get_user(request, session)
    if not user:
        return RedirectResponse(url="/login")

    user_orders = session.exec(select(Order).filter_by(user_id=user.id)).scalars().all()
    items = session.exec(select(Item)).scalars().all()
    items = {item.id: item for item in items}
    return templates.TemplateResponse("orders.html", {"title": "Orders", "request": request, "user": user, "order_count": order_count, "orders": user_orders, "items": items, "error": error, "success": success})


def stream_sell_orders(session: Session, orders: list[Order]):
    for order in orders:

        def sell_order(user: User):
            if not order or order.user_id != user.id:
                return False
            item = session.get(Item, order.item_id)
            user.balance += item.price
            session.delete(order)
            session.commit()
            return True

        yield sell_order


@app.post("/orders")
async def sell(request: Request, session: SessionDep, order_ids: list[int] = Form(...)):
    user, _ = get_user(request, session)
    if not user:
        return RedirectResponse(url="/login?error=Please log in to sell items", status_code=303)
    order_ids = list(set(order_ids))
    for sell_order in list(stream_sell_orders(session, [session.get(Order, order_id) for order_id in order_ids])):
        if not sell_order(user):
            return await orders(request, error="Failed to sell all orders", session=session)

    return await orders(request, success="Items sold successfully", session=session)


@app.exception_handler(StarletteHTTPException)
@app.exception_handler(HTTPException)
@app.exception_handler(RequestValidationError)
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    if isinstance(exc, (StarletteHTTPException, HTTPException)):
        status_code = exc.status_code
        error_title = f"{status_code} - {exc.detail}"
        error_description = "Whelp, that's embarrasing"
    elif isinstance(exc, RequestValidationError):
        status_code = 422
        error_title = "422 - Validation Error"
        error_description = str(exc)
    else:
        status_code = 500
        error_title = "500 - Internal Server Error"
        error_description = "An unexpected error occurred."

    img = "404.png" if status_code == 404 else "500.png"
    return templates.TemplateResponse(
        "error.html",
        {
            "request": request,
            "code": status_code,
            "error_title": error_title,
            "error_description": error_description,
            "img": img,
        },
        status_code=status_code,
    )
