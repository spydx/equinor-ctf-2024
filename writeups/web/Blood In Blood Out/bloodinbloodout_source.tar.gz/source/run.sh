#!/bin/bash
/usr/local/tomcat/bin/catalina.sh run &
sleep 10
/usr/local/tomcat/victim.sh