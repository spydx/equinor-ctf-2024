import { NextRequest, NextResponse } from "next/server";

// Make sure we are fully SSR complient and not using any client-side JS
export async function middleware(request: NextRequest) {
  if (request.headers.get("Next-Action")) {
    return new NextResponse(null, { status: 403 });
  }
  const response = NextResponse.next();
  if (response.headers.get("Content-Type")?.toLowerCase().includes("text/x-component")) {
    return new NextResponse(null, { status: 403 });
  }
  response.headers.set("Content-Security-Policy", "script-src 'none';");
  return response;
}

export const config = {
  matcher: "/:path*",
};
