"use server";

import { getUser, getUserItems, removeItem, setMoney } from "../db";
import { redirect } from "next/navigation";
import Image from "next/image";

export default async function ItemsPage({ searchParams }: { readonly searchParams: { [key: string]: string | string[] | undefined } }) {
  const error = searchParams.error as string | undefined;
  const success = searchParams.success as string | undefined;

  const user = await getUser();
  if (!user) {
    redirect("/login?error=Please log in");
  }
  const userItems = await getUserItems(user.id);

  return (
    <div className="container mt-4">
      <h1 className="mb-4">My Items</h1>

      {error && <div className="alert alert-danger mb-4">{error}</div>}
      {success && <div className="alert alert-success mb-4">{success}</div>}

      {userItems.length === 0 ? (
        <p>You don&apos;t own any items yet.</p>
      ) : (
        <div className="table-responsive">
          <table className="table table-hover">
            <thead>
              <tr>
                <th>Item</th>
                <th>Description</th>
                <th>Value</th>
                <th>Note</th>
                <th>Sell</th>
              </tr>
            </thead>
            <tbody>
              {userItems.map((item) => (
                <tr key={item.name}>
                  <td className="align-middle">
                    <div className="d-flex align-items-center">
                      <Image src={item.image} alt={item.name} width={50} height={50} className="me-3 rounded" />
                      <span>{item.name}</span>
                    </div>
                  </td>
                  <td className="align-middle">{item.description}</td>
                  <td className="align-middle">${item.price.toFixed(2)}</td>
                  <td className="align-middle">{item.note ?? "N/A"}</td>
                  <td className="align-middle">
                    <form
                      action={async () => {
                        "use server";
                        if (user.retailer) {
                          removeItem(item.name);
                          setMoney(user.money + item.price);
                        } else {
                          redirect("/items?error=Only retailers can sell items");
                        }
                      }}
                    >
                      <button type="submit" className="btn btn-danger">
                        Sell
                      </button>
                    </form>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
