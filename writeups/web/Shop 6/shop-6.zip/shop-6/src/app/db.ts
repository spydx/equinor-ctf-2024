"use server";

import { Database } from "bun:sqlite";
import { cookies } from "next/headers";

import funImage from "./images/fun.png";
import toteBagImage from "./images/tote-bag.png";
import laptopImage from "./images/laptop.png";
import smartphoneImage from "./images/smartphone.png";
import headphonesImage from "./images/headphones.png";
import smartwatchImage from "./images/smartwatch.png";
import cameraImage from "./images/camera.png";

export interface Item {
  id: number;
  name: string;
  description: string;
  price: number;
  note?: string;
  image: string;
  rating: number;
  inStock: boolean;
}

export interface User {
  id: number;
  name: string;
  password: string;
  token: string;
  money: number;
  retailer: boolean;
}

const db = new Database("./shop.db");
db.run("PRAGMA busy_timeout = 5000;");
db.run("PRAGMA journal_mode = WAL;");
const tableExists = db.query("SELECT name FROM sqlite_master WHERE type='table' AND name='users'").get();

if (!tableExists) {
  console.log("Database not initialized. Initializing...");

  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE,
      password TEXT,
      token TEXT UNIQUE,
      money REAL,
      retailer BOOLEAN
    );
    CREATE TABLE IF NOT EXISTS items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE,
      description TEXT,
      price REAL,
      note TEXT,
      image TEXT,
      rating REAL,
      inStock INTEGER
    );
    CREATE TABLE IF NOT EXISTS user_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      item_id INTEGER,
      FOREIGN KEY(user_id) REFERENCES users(id),
      FOREIGN KEY(item_id) REFERENCES items(id)
    );
  `);

  const initialItems = [
    {
      name: "Fun",
      description: "Our most fun product yet!",
      price: 99.99,
      image: funImage.src,
      rating: 4.9,
      inStock: true,
    },
    {
      name: "EPT Tote Bag",
      description: "A handy EPT tote bag to carry all your EPT merch!",
      price: 2499.99,
      note: "Come over to the admin booth and claim your very own EPT tote bag for you and your team! " + (process.env["FLAG"] || "flag{fake-flag}"),
      image: toteBagImage.src,
      rating: 5.0,
      inStock: true,
    },
    {
      name: "Laptop",
      description: "Powerful laptop for work and gaming",
      price: 999.99,
      image: laptopImage.src,
      rating: 4.5,
      inStock: false,
    },
    {
      name: "Smartphone",
      description: "Latest smartphone with advanced features",
      price: 699.99,
      image: smartphoneImage.src,
      rating: 4.7,
      inStock: false,
    },
    {
      name: "Headphones",
      description: "Noise-cancelling headphones for immersive audio",
      price: 249.99,
      image: headphonesImage.src,
      rating: 4.2,
      inStock: false,
    },
    {
      name: "Smartwatch",
      description: "Fitness tracker and smartwatch in one",
      price: 199.99,
      image: smartwatchImage.src,
      rating: 4.0,
      inStock: false,
    },
    {
      name: "Camera",
      description: "Professional-grade camera for stunning photos",
      price: 1499.99,
      image: cameraImage.src,
      rating: 4.8,
      inStock: false,
    },
  ];

  const insertItem = db.prepare(`
    INSERT OR IGNORE INTO items (name, description, price, note, image, rating, inStock)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  for (const item of initialItems) {
    insertItem.run(item.name, item.description, item.price, item.note || null, item.image, item.rating, item.inStock ? 1 : 0);
  }
  console.log(`Database initialized. ${db.query("SELECT id FROM items").all().length} items inserted.`);
}

export async function getItems(): Promise<Item[]> {
  return db.query("SELECT * FROM items").all() as Item[];
}

export async function getUser(): Promise<User | null> {
  const token = cookies().get("token")?.value;
  if (!token) return null;
  return db.query("SELECT * FROM users WHERE token = ?").get(token) as User | null;
}

export async function addItem(itemName: string): Promise<boolean> {
  const user = await getUser();
  if (!user) return false;

  const item = db.query("SELECT id FROM items WHERE name = ?").get(itemName) as Item | undefined;
  if (!item) return false;

  db.run("INSERT INTO user_items (user_id, item_id) VALUES (?, ?)", [user.id, item.id]);
  return true;
}

export async function removeItem(itemName: string): Promise<boolean> {
  const user = await getUser();
  if (!user) return false;

  const item = db.query("SELECT id FROM items WHERE name = ?").get(itemName) as Item | undefined;
  if (!item) return false;

  db.run("DELETE FROM user_items WHERE id = (SELECT id FROM user_items WHERE user_id = ? AND item_id = ? LIMIT 1)", [user.id, item.id]);
  return true;
}

export async function setMoney(amount: number): Promise<boolean> {
  const user = await getUser();
  if (!user) return false;

  db.run("UPDATE users SET money = ? WHERE id = ?", [amount, user.id]);
  return true;
}

export async function getUserByName(name: string): Promise<User | null> {
  return db.query("SELECT * FROM users WHERE name = ?").get(name) as User | null;
}

export async function getUserItems(userId: number): Promise<Item[]> {
  return db
    .query(
      `
    SELECT items.*
    FROM user_items
    JOIN items ON user_items.item_id = items.id
    WHERE user_items.user_id = ?
  `
    )
    .all(userId) as Item[];
}

export async function createUser(username: string, password: string, token: string): Promise<User | null> {
  const result = db.run("INSERT INTO users (name, password, token, money, retailer) VALUES (?, ?, ?, ?, ?)", [username, password, token, 100, 0]);
  return result.lastInsertRowid ? ({ id: Number(result.lastInsertRowid), name: username, password, token, money: 100, retailer: false } as User) : null;
}

export async function makeRetailer(): Promise<boolean> {
  const user = await getUser();
  if (!user) return false;

  db.run("UPDATE users SET retailer = ? WHERE id = ?", [true, user.id]);
  return true;
}
