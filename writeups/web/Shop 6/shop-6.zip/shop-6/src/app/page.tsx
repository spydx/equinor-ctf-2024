"use server";

import { getItems, getUser, getUserItems } from "./db";
import ItemCard from "./components/ItemCard";
import LoginModal from "./components/LoginModal";

export default async function Home({ searchParams }: { readonly searchParams: { [key: string]: string | string[] | undefined } }) {
  const items = await getItems();
  const error = searchParams.error as string | undefined;
  const success = searchParams.success as string | undefined;
  const login = searchParams.hasOwnProperty("login");
  const user = await getUser();
  const userItems = user ? await getUserItems(user.id) : [];
  return (
    <div className="container mt-4">
      {error && !login && <div className="alert alert-danger mb-4">{error}</div>}
      {success && <div className="alert alert-success mb-4">{success}</div>}
      <LoginModal isOpen={login} error={error} />
      <div className="row">
        {items.map((item) => (
          <ItemCard key={item.name} user={user} userItems={userItems} item={item} />
        ))}
      </div>
    </div>
  );
}
