"use server";

import Image from "next/image";
import errorImage from "./images/404.png";

export default async function NotFound() {
  const errorTitle = "404 - Page Not Found";
  const errorDescription = "The page you are looking for does not exist.";

  return (
    <div className="container">
      <div className="row align-items-center min-vh-100">
        <div className="col-md-6">
          <div className="bg-light p-4 rounded shadow">
            <h1 className="display-4 mb-4">{errorTitle}</h1>
            <p className="lead mb-4">{errorDescription}</p>
            <p>Don&apos;t worry, we&apos;re here to help. You can try the following:</p>
            <ul className="mb-4">
              <li>Double-check the URL for any typos</li>
              <li>Go back to the previous page</li>
              <li>Visit our homepage</li>
              <li>Try searching on your favorite search engine for help</li>
              <li>Consider asking a LLM for help</li>
              <li>Check out the source code of the challenge to know what happens behind the scene</li>
              <li>Reconsider your life choices on how you ended up here</li>
              <li>If none of the above works, I don&apos;t even know what you want any more. I&apos;m just a React component, I can&apos;t really help you any more than that 😕</li>
            </ul>
            <a href="/" className="btn btn-primary">
              Go back to the homepage
            </a>
          </div>
        </div>
        <div className="col-md-6">
          <Image src={errorImage} alt="Error Illustration" className="img-fluid" width={500} height={500} />
        </div>
      </div>
    </div>
  );
}
