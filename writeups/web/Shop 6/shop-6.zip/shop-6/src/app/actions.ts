"use server";

import { cookies } from "next/headers";
import { createUser, getUserByName } from "./db";
import crypto from "crypto";
import { redirect } from "next/navigation";

export async function registerUser(formData: FormData) {
  const username = formData.get("username") as string;
  const password1 = formData.get("password1") as string;
  const password2 = formData.get("password2") as string;

  if (password1 !== password2) {
    return redirect("/register?error=Passwords do not match");
  }

  const existingUser = await getUserByName(username);
  if (existingUser) {
    return redirect("/register?error=User already exists");
  }

  const token = crypto.randomBytes(16).toString("hex");
  const hashedPassword = crypto.createHash("sha256").update(password1).digest("hex");

  if (await createUser(username, hashedPassword, token)) {
    redirect("/login?success=Registration successful! Please log in.");
  } else {
    redirect("/register?error=Something went wrong, please try again.");
  }
}

export async function loginUser(formData: FormData) {
  const username = formData.get("username") as string;
  const password = formData.get("password") as string;

  const user = await getUserByName(username);
  if (!user) {
    return redirect("/login?error=User not found");
  }

  const hashedPassword = crypto.createHash("sha256").update(password).digest("hex");
  if (user.password !== hashedPassword) {
    return redirect("/login?error=Invalid credentials");
  }

  cookies().set("token", user.token, { httpOnly: true });
  redirect("/");
}
