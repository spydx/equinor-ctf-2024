import type { Metadata } from "next";
import Navbar from "./components/Navbar";
import logo from "./images/logo.png";
import Script from "next/script";

export const metadata: Metadata = {
  title: "EPT Shop",
  description: "Shop for EPT merchandise",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href={logo.src} type="image/png" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" />
      </head>
      <body>
        <Navbar />
        <main className="container mt-4">{children}</main>
        <Script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js" />
      </body>
    </html>
  );
}
