"use server";

import { loginUser } from "../actions";

interface LoginModalProps {
  isOpen: boolean;
  error?: string;
}

export default async function LoginModal({ isOpen, error }: LoginModalProps) {
  if (!isOpen) return null;

  return (
    <>
      <div className="modal-backdrop fade show"></div>
      <div className="modal d-block" tabIndex={-1} role="dialog">
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header bg-primary text-white">
              <h5 className="modal-title">Login</h5>
              <a href="/" className="btn-close btn-close-white" aria-label="Close"></a>
            </div>
            <div className="modal-body">
              {error && <div className="alert alert-danger mb-4">{error}</div>}
              <form action={loginUser}>
                <div className="mb-3">
                  <label htmlFor="username" className="form-label">
                    Username
                  </label>
                  <div className="input-group">
                    <span className="input-group-text">
                      <i className="bi bi-person-fill"></i>
                    </span>
                    <input type="text" className="form-control" id="username" name="username" required />
                  </div>
                </div>
                <div className="mb-3">
                  <label htmlFor="password" className="form-label">
                    Password
                  </label>
                  <div className="input-group">
                    <span className="input-group-text">
                      <i className="bi bi-lock-fill"></i>
                    </span>
                    <input type="password" className="form-control" id="password" name="password" required />
                  </div>
                </div>
                <div className="d-flex align-items-center justify-content-between mt-4 mb-0">
                  <button type="submit" className="btn btn-primary">
                    Login
                  </button>
                </div>
              </form>
            </div>
            <div className="modal-footer">
              <div className="text-center w-100">
                <small>
                  <a href="/register">Need an account? Sign up!</a>
                </small>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
