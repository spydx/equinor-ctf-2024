"use server";

import Image from "next/image";
import { getUser, getUserItems } from "../db";
import logo from "../images/logo.png";

export default async function Navbar() {
  const user = await getUser();
  const userItems = user ? await getUserItems(user.id) : [];

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light">
      <div className="container">
        <a href="/" className="navbar-brand">
          <Image src={logo} alt="EPT Webshop Logo" height={30} width={30} className="d-inline-block align-top me-2" />
          Webshop
        </a>
        <div className="navbar-nav ms-auto">
          {user ? (
            <>
              <span className="nav-item nav-link">Balance: ${user.money.toFixed(2)}</span>
              <span className="nav-item nav-link">Items: {userItems.length}</span>
              <a href="/items" className="nav-link">
                My Items
              </a>
              <a href="/logout" className="nav-link">
                Logout
              </a>
            </>
          ) : (
            <>
              <a href="/login" className="nav-link">
                Login
              </a>
              <a href="/register" className="nav-link">
                Register
              </a>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
