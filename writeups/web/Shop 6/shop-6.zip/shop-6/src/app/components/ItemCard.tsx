"use server";

import Image from "next/image";
import { User, Item, addItem, setMoney } from "../db";
import { redirect } from "next/navigation";

export default async function ItemCard({ user, item, userItems }: { readonly user: User | null; readonly item: Item; readonly userItems: Item[] }) {
  return (
    <div className="col-md-4 mb-4">
      <div className="card">
        <Image src={item.image} alt={item.name} width={414} height={414} className="card-img-top" style={{ height: "auto" }} />
        <div className="card-body">
          <h5 className="card-title">{item.name}</h5>
          <p className="card-text">{item.description}</p>
          <p className="card-text">
            <strong>Price:</strong> ${item.price.toFixed(2)}
            <br />
            <strong>Rating:</strong> {item.rating.toFixed(1)} / 5.0
            <br />
            <strong>Owned:</strong> {userItems.filter((userItem) => userItem.name == item.name).length ?? 0}
          </p>
          {item.inStock ? (
            <div>
              <form
                action={async () => {
                  "use server";
                  if (user) {
                    if (user?.money >= item.price) {
                      addItem(item.name);
                      setMoney(user?.money - item.price);
                    } else {
                      redirect(`/?error=Insufficient funds to buy ${item.name}`);
                    }
                  } else {
                    redirect(`/?login&error=You need to login in order to buy ${item.name}`);
                  }
                }}
              >
                <button type="submit" className="btn btn-primary">
                  Buy
                </button>
              </form>
            </div>
          ) : (
            <button className="btn btn-primary" disabled>
              Out of Stock
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
