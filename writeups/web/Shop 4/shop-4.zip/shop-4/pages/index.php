<?php
$title = "Shop - EPT Webshop";
require_once "/utils/db.php";

$user = getCurrentUser();
if (!$user) {
    header('Location: /login');
    exit;
}

$user_items = getItemsByUserId($user['id']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item_id = $_POST['item_id'];
    $action = $_POST['action'];

    $item = getItemById($item_id);
    if (!$item) {
        $messages[] = [
            "category" => "danger",
            "message" => "Item not found."
        ];
    } elseif ($action === 'buy') {
        if ($item['in_stock']) {
                if ($user['balance'] >= $item['price']) {
                    if (updateUserbalance($user['id'], -$item['price'])) {
                    if (addUserItem($user['id'], $item_id)) {
                        $messages[] = [
                            "category" => "success",
                            "message" => "Item purchased successfully!"
                        ];
                        $user = getCurrentUser();
                        $user_items = getItemsByUserId($user['id']);
                    } else {
                        $messages[] = [
                            "category" => "danger",
                            "message" => "Error adding item to user inventory."
                        ];
                        updateUserbalance($user['id'], $item['price']);
                    }
                } else {
                    $messages[] = [
                        "category" => "danger",
                        "message" => "Error updating user balance."
                    ];
                }
            } else {
                $messages[] = [
                    "category" => "danger",
                    "message" => "Not enough money to buy this item."
                ];
            }
        } else {
            $messages[] = [
                "category" => "danger",
                "message" => "Item is out of stock."
            ];
        }
    } elseif ($action === 'refund') {
        if (isset($user_items[$item_id]) && $user_items[$item_id] > 0) {
            if (updateUserbalance($user['id'], $item['price'])) {
                if (removeUserItem($user['id'], $item_id)) {
                    $messages[] = [
                        "category" => "success",
                        "message" => "Item refunded successfully!"
                    ];
                    $user = getCurrentUser();
                    $user_items = getItemsByUserId($user['id']);
                } else {
                    $messages[] = [
                        "category" => "danger",
                        "message" => "Error removing item from user inventory."
                    ];
                    updateUserbalance($user['id'], -$item['price']);
                }
            } else {
                $messages[] = [
                    "category" => "danger",
                    "message" => "Error updating user balance."
                ];
            }
        } else {
            $messages[] = [
                "category" => "danger",
                "message" => "You don't own this item."
            ];
        }
    }
}

require_once "/utils/header.php";
require_once "/utils/messages.php";

$items = getItems();

?>

<div class="card mb-4">
    <div class="card-body d-flex justify-content-between align-items-center">
        <div>
            <h4 class="card-title mb-0">Welcome, <span class="text-primary"><?= htmlspecialchars($user['username']) ?></span>!</h4>
        </div>
        <div class="text-end">
            <p class="card-text mb-0">Your balance:</p>
            <h5 class="card-title mb-0"><strong>$<?= number_format($user['balance'], 2) ?></strong></h5>
        </div>
    </div>
</div>

<div class="row">
    <?php foreach ($items as $item_id => $item): ?>
    <div class="col-md-4 mb-4">
        <div class="card h-100">
            <img src="<?= $item['image'] ?>" class="card-img-top" alt="<?= $item['name'] ?>" />
            <div class="card-body">
                <h5 class="card-title"><?= htmlspecialchars($item['name']) ?></h5>
                <p class="card-text"><?= htmlspecialchars($item['description']) ?></p>
                <p class="card-text">
                    <strong>Price:</strong> $<?= number_format($item['price'], 2) ?><br />
                    <strong>Rating:</strong> <?= number_format($item['rating'], 1) ?> / 5.0<br />
                    <strong>Owned:</strong> <?= isset($user_items[$item_id]) ? $user_items[$item_id] : 0 ?>
                </p>
                <form method="POST" class="d-inline">
                    <input type="hidden" name="item_id" value="<?= $item_id ?>">
                    <input type="hidden" name="action" value="buy">
                    <button type="submit" class="btn btn-primary" <?= $item['in_stock'] ? '' : 'disabled' ?>>
                        <?= $item['in_stock'] ? 'Buy' : 'Out of Stock' ?>
                    </button>
                </form>
                <?php if (isset($user_items[$item_id]) && $user_items[$item_id] > 0): ?>
                    <form method="POST" class="d-inline">
                        <input type="hidden" name="item_id" value="<?= $item_id ?>">
                        <input type="hidden" name="action" value="refund">
                        <button type="submit" class="btn btn-secondary">Refund</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php require_once "/utils/footer.php"; ?>