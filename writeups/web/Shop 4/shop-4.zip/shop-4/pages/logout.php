<?php
require_once "/utils/db.php";

setcookie('session_token', '', time() - 3600, '/');
header('Location: /login');
exit;
