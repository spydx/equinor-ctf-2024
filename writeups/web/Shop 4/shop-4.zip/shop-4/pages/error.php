<?php
if (!isset($_GET["code"])) {
    $code = "404";
} else {
    $code = $_GET["code"];
}
if (!in_array($code, ["404", "500"])) {
    $code = "404";
}
require_once "/utils/error.php";
?>
