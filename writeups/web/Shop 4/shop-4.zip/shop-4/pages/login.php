<?php
require_once "/utils/db.php";

$user = getCurrentUser();
if ($user) {
  header('Location: /');
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = $_POST['username'];
  $password = $_POST['password'];

  $user_db = getUserByUsername($username);

  if ($user_db && password_verify($password, $user_db['password'])) {
      setcookie('session_token', $user_db['session_token'], time() + 3600, '/');
      header('Location: /');
      exit;
  } else {
      $messages[] = [
        "category" => "danger",
        "message" => "Invalid username or password."
      ];
  }
}

$title = "Login - EPT Webshop";
require_once "/utils/header.php";
require_once "/utils/messages.php";
?>
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow-lg border-0 rounded-lg mt-5">
        <div class="card-header bg-primary text-white">
          <h3 class="text-center font-weight-light my-4">Login</h3>
        </div>
        <div class="card-body">
          <form method="POST">
            <div class="mb-3">
              <label for="username" class="form-label">Username</label>
              <div class="input-group">
                <span class="input-group-text"><i class="bi bi-person-fill"></i></span>
                <input type="text" class="form-control" id="username" name="username" required />
              </div>
            </div>
            <div class="mb-3">
              <label for="password" class="form-label">Password</label>
              <div class="input-group">
                <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                <input type="password" class="form-control" id="password" name="password" required />
              </div>
            </div>
            <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
              <a class="small" href="#">Forgot Password?</a>
              <button type="submit" class="btn btn-primary">Login</button>
            </div>
          </form>
        </div>
        <div class="card-footer text-center py-3">
          <div class="small"><a href="/register">Need an account? Sign up!</a></div>
        </div>
      </div>
    </div>
  </div>
