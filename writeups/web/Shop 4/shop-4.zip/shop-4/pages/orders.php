<?php
require_once "/utils/db.php";
$user = getCurrentUser();
if (!$user) {
    header('Location: login');
    exit;
}
$orders = getOrdersByUserId($user['id']);
$items = getItems();
$title = "My Orders - EPT Webshop";
require_once "/utils/header.php";
?>
  <h1 class="mb-4">My Orders</h1>
  <table class="table">
    <thead>
      <tr>
        <th>Order ID</th>
        <th>Item</th>
        <th>Date</th>
        <th>Note</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($orders as $order): ?>
      <tr>
        <td><?= $order['id']; ?></td>
        <td><?= $items[$order['item_id']]['name']; ?></td>
        <td><?= $order['date']; ?></td>
        <td><?= $items[$order['item_id']]['note']; ?></td>
        <td>
          <form action="/" method="POST" class="d-inline">
              <input type="hidden" name="item_id" value="<?= $order['item_id'] ?>">
              <input type="hidden" name="action" value="refund">
              <button type="submit" class="btn btn-warning btn-sm">Refund</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
<?php
require_once "/utils/footer.php";
