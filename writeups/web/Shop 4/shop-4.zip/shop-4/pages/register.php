<?php
require_once "/utils/db.php";

$user = getCurrentUser();
if ($user) {
  header('Location: /');
  exit;
}

require_once "/utils/header.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password !== $confirm_password) {
        $messages[] = [
            "category" => "danger",
            "message" => "Passwords do not match."
        ];
    } else {
        $password = password_hash($password, PASSWORD_DEFAULT);
        $session_token = bin2hex(random_bytes(32));

        if (getUserByUsername($username)) {
          $messages[] = [
            "category" => "danger",
            "message" => "Registration failed. Username already taken."
          ];
        } elseif (registerUser($username, $password, 100, $session_token)) {
            $messages[] = [
            "category" => "success",
            "message" => "Registration successful. Please log in."
          ];
        } else {
          $messages[] = [
            "category" => "danger",
            "message" => "Registration failed unexpected error."
          ];
        }
    }
}
require_once "/utils/messages.php";
?>
<div class="row justify-content-center">
  <div class="col-md-6">
    <div class="card shadow-lg border-0 rounded-lg mt-5">
      <div class="card-header bg-primary text-white">
        <h3 class="text-center font-weight-light my-4">Create Account</h3>
      </div>
      <div class="card-body">
        <form method="POST">
          <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <div class="input-group">
              <span class="input-group-text"><i class="bi bi-person-fill"></i></span>
              <input type="text" class="form-control" id="username" name="username" required />
            </div>
          </div>
          <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <div class="input-group">
              <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
              <input type="password" class="form-control" id="password" name="password" required />
            </div>
          </div>
          <div class="mb-3">
            <label for="confirm_password" class="form-label">Confirm Password</label>
            <div class="input-group">
              <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
              <input type="password" class="form-control" id="confirm_password" name="confirm_password" required />
            </div>
          </div>
          <div class="mt-4 mb-0">
            <div class="d-grid">
              <button type="submit" class="btn btn-primary btn-block">Create Account</button>
            </div>
          </div>
        </form>
      </div>
      <div class="card-footer text-center py-3">
        <div class="small"><a href="/login">Have an account? Go to login</a></div>
      </div>
    </div>
  </div>
</div>

<?php
require_once "/utils/footer.php";
