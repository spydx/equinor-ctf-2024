document.addEventListener("DOMContentLoaded", function () {
  const cards = document.querySelectorAll(".card-link");
  cards.forEach((card) => {
    card.addEventListener("click", function (e) {
      if (e.target.tagName !== "A") {
        e.preventDefault();
        window.location.href = this.href;
      }
    });
  });
});
