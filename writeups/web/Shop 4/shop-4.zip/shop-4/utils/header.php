<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?= isset($title) ? $title : "EPT Webshop" ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="/style.css" />
    <link rel="icon" type="image/png" href="/images/logo.png" />
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container">
        <a class="navbar-brand" href="/">
          <img src="/images/logo.png" alt="EPT Webshop Logo" height="30" class="d-inline-block align-top me-2">
          Webshop
        </a>
        <div class="navbar-nav ms-auto">
          <?php if (isset($user)): ?>
          <span class="nav-item nav-link">Balance: $<?= number_format($user["balance"], 2) ?></span>
          <span class="nav-item nav-link">Orders: <?= $user["order_count"] ?></span>
          <a class="nav-link" href="/orders">My Orders</a>
          <a class="nav-link" href="/logout">Logout</a>
          <?php else: ?>
          <a class="nav-link" href="/login">Login</a>
          <a class="nav-link" href="/register">Register</a>
          <?php endif; ?>
        </div>
      </div>
    </nav>

    <div class="container mt-4">