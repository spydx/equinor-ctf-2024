<?php
if (!isset($code)) {
    $code = "500";
}
if ($code == "404") {
    if (!isset($error_title)) {
        $error_title = "404 - Page not found";
    }
    if (!isset($error_description)) {
        $error_description = "The page you are looking for does not exist.";
    }
} else if ($code == "500") {
    if (!isset($error_title)) {
        $error_title = "500 - Internal server error";
    }
    if (!isset($error_description)) {
        $error_description = "An error occurred while processing your request.";
    }
}
if (!in_array($code, ["404", "500"])) {
    $code = "500";
}
http_response_code($code);
if (!isset($img)) {
    $img = $code . ".png";
}
$title = "Error " . $error_title . " - EPT Webshop";
require_once "/utils/header.php";
?>
<div class="row align-items-center min-vh-100">
    <div class="col-md-6">
        <div class="bg-light p-4 rounded shadow">
            <h1 class="display-4 mb-4"><?= $error_title; ?></h1>
            <p class="lead mb-4"><?= $error_description; ?></p>
            <p>Don't worry, we're here to help. You can try the following:</p>
            <ul class="mb-4">
                <li>Double-check the URL for any typos</li>
                <li>Go back to the previous page</li>
                <li>Visit our homepage</li>
                <li>Try searching on your favorite search engine for help</li>
                <li>Consider asking a LLM for help</li>
                <li>Check out the source code of the challenge to know what happens behind the scene</li>
                <li>Reconsider your life choices on how you neded up here</li>
                <li>If none of the above works, I don't even know what you want any more. I'm just a php script, I can't really help you any more than that 😕</li>
            </ul>
            <a href="/" class="btn btn-primary">Go back to the homepage</a>
        </div>
    </div>
    <div class="col-md-6">
        <img src="/images/<?= $img; ?>" alt="Error Illustration" class="img-fluid">
    </div>
</div>
<?php
require_once "/utils/footer.php";
exit();
?>