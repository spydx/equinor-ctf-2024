<?php
function getDBConnection() {
    if (!extension_loaded('mysqli')) {
        throw new \Exception('mysqli extension is not available');
    }

    $db_url = getenv('DB_URL');
    if (!$db_url) {
        throw new \Exception('DB_URL environment variable is not set');
    }

    $url = parse_url($db_url);
    $host = $url['host'];
    $db   = substr($url['path'], 1);
    $user = $url['user'];
    $pass = $url['pass'];

    try {
        $mysqli = new mysqli($host, $user, $pass, $db);
        if ($mysqli->connect_errno) {
            throw new \Exception("Failed to connect to MySQL: " . $mysqli->connect_error);
        }
        $mysqli->set_charset('utf8mb4');
        return $mysqli;
    } catch (\Exception $e) {
        throw new \Exception($e->getMessage(), (int)$e->getCode());
    }
}

function populateDB() {
    $db = getDBConnection();

    $db->query('CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) UNIQUE,
        password VARCHAR(255),
        session_token VARCHAR(255),
        balance INT
    )');

    $db->query('CREATE TABLE IF NOT EXISTS items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) UNIQUE,
        description TEXT,
        note VARCHAR(255),
        price INT,
        image VARCHAR(255),
        rating FLOAT,
        in_stock BOOLEAN
    )');

    $db->query('CREATE TABLE IF NOT EXISTS orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        item_id INT,
        date DATETIME
    )');

    $flag = file_get_contents('/flag.txt');
    $db->query(str_replace('%flag%', $flag, "INSERT IGNORE INTO items (name, description, price, note, image, rating, in_stock) VALUES
        ('Fun', 'Our most fun product yet!', 99.99, 'Here you go, you are now having fun!', '/images/fun.png', 4.8, 1),
        ('EPT Fan', 'This fan will blow you away!', 2499.99, 'Come over to the admin booth and claim your very own EPT Fan for you and your team!', '/images/fan.png', 5.0, 1),
        ('Flag', 'One of those really nice looking flags', 1337.99, '%flag%', '/images/flag.png', 4.9, 1),
        ('Laptop', 'Powerful laptop for work and gaming', 999.99, NULL, '/images/laptop.png', 4.5, 0),
        ('Smartphone', 'Latest smartphone with advanced features', 699.99, NULL, '/images/smartphone.png', 4.2, 0),
        ('Headphones', 'Noise-cancelling headphones for immersive audio', 249.99, NULL, '/images/headphones.png', 4.7, 0),
        ('Smartwatch', 'Fitness tracker and smartwatch in one', 199.99, NULL, '/images/smartwatch.png', 4.0, 0),
        ('Camera', 'Professional-grade camera for stunning photos', 1499.99, NULL, '/images/camera.png', 4.8, 0)
    "));
}

function getCurrentUser() {
    if (isset($_COOKIE) && isset($_COOKIE['session_token'])) {
        $db = getDBConnection();
        $stmt = $db->prepare('SELECT u.id, u.username, u.balance, COUNT(o.id) as order_count
                              FROM users u
                              LEFT JOIN orders o ON u.id = o.user_id
                              WHERE u.session_token = ?
                              GROUP BY u.id');
        $stmt->bind_param('s', $_COOKIE['session_token']);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    return null;
}

function getUserByUsername($username) {
    $db = getDBConnection();
    $stmt = $db->prepare('SELECT * FROM users WHERE username = ?');
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

function registerUser($username, $password, $balance, $session_token) {
    $db = getDBConnection();
    $stmt = $db->prepare('INSERT INTO users (username, password, balance, session_token) VALUES (?, ?, ?, ?)');
    $stmt->bind_param('ssis', $username, $password, $balance, $session_token);
    return $stmt->execute();
}

function getItemsByUserId($userId) {
    $db = getDBConnection();
    $stmt = $db->prepare('SELECT id, item_id, COUNT(*) as count FROM orders WHERE user_id = ? GROUP BY item_id');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $items = [];
    while ($row = $result->fetch_assoc()) {
        $items[$row['item_id']] = $row['count'];
    }
    return $items;
}

function getOrdersByUserId($userId) {
    $db = getDBConnection();
    $stmt = $db->prepare('SELECT * FROM orders WHERE user_id = ?');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function getOrderById($orderId) {
    $db = getDBConnection();
    $stmt = $db->prepare('SELECT * FROM orders WHERE id = ?');
    $stmt->bind_param('i', $orderId);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

function getItemById($itemId) {
    $db = getDBConnection();
    $stmt = $db->prepare('SELECT * FROM items WHERE id = ?');
    $stmt->bind_param('i', $itemId);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

function getItems() {
    $db = getDBConnection();
    $stmt = $db->prepare('SELECT * FROM items');
    $stmt->execute();
    $result = $stmt->get_result();
    $items = [];
    while ($row = $result->fetch_assoc()) {
        $items[$row['id']] = $row;
    }
    return $items;
}

function updateUserbalance($userId, $balance) {
    $db = getDBConnection();
    $stmt = $db->prepare('UPDATE users SET balance = balance + ? WHERE id = ?');
    $stmt->bind_param('di', $balance, $userId);
    return $stmt->execute();
}

function addUserItem($userId, $itemId, $date = null) {
    if ($date === null) {
        $date = date('Y-m-d H:i:s');
    }
    $db = getDBConnection();
    $stmt = $db->prepare('INSERT INTO orders (user_id, item_id, date) VALUES (?, ?, ?)');
    $stmt->bind_param('iis', $userId, $itemId, $date);
    return $stmt->execute();
}

function removeUserItem($userId, $itemId) {
    $db = getDBConnection();
    $stmt = $db->prepare('DELETE FROM orders WHERE user_id = ? AND item_id = ? LIMIT 1');
    $stmt->bind_param('di', $userId, $itemId);
    return $stmt->execute();
}
