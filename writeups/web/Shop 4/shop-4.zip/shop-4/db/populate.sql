CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) UNIQUE,
    password VARCHAR(255),
    session_token VARCHAR(255),
    balance FLOAT
);

CREATE TABLE IF NOT EXISTS items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) UNIQUE,
    description TEXT,
    note VARCHAR(255),
    price FLOAT,
    image VARCHAR(255),
    rating FLOAT,
    in_stock BOOLEAN
);

CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    item_id INT,
    date DATETIME
);

INSERT IGNORE INTO items (name, description, price, note, image, rating, in_stock) VALUES
    ('Race Car', 'A blazingly fast toy race car!', 99.99, 'An imaginary toy race car almost as fast as our frontend!', '/images/race-car.png', 4.8, 1),
    ('EPT Fan', 'This fan will blow you away!', 2499.99, 'Come over to the admin booth and claim your very own EPT Fan for you and your team! __FLAG__', '/images/fan.png', 5.0, 1),
    ('Laptop', 'Powerful laptop for work and gaming', 999.99, NULL, '/images/laptop.png', 4.5, 0),
    ('Smartphone', 'Latest smartphone with advanced features', 699.99, NULL, '/images/smartphone.png', 4.2, 0),
    ('Headphones', 'Noise-cancelling headphones for immersive audio', 249.99, NULL, '/images/headphones.png', 4.7, 0),
    ('Smartwatch', 'Fitness tracker and smartwatch in one', 199.99, NULL, '/images/smartwatch.png', 4.0, 0),
    ('Camera', 'Professional-grade camera for stunning photos', 1499.99, NULL, '/images/camera.png', 4.8, 0);