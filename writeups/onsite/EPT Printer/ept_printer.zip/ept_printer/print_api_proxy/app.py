import os

import requests
from flask import Flask, jsonify, request

app = Flask(__name__)

PRINT_API_URL = os.getenv("PRINT_API_URL")
PRINT_API_KEY = os.getenv("PRINT_API_KEY")


@app.route("/jobs", methods=["POST"])
def create_job():
    if "pdf" not in request.files:
        app.logger.error("No PDF file provided")
        return jsonify({"error": "No PDF file provided"}), 400

    card_id = request.form.get("card_id")
    if not card_id:
        app.logger.error("No card ID provided")
        return jsonify({"error": "No card_id provided"}), 400

    pdf_file = request.files["pdf"]

    if not PRINT_API_URL or PRINT_API_URL.strip() == "":
        return (
            jsonify(
                {
                    "error": "The print proxy does not have a PRINT_API_URL set (i.e. is not running in production mode). You will only be able to send actual print jobs from the ondemand challenge. If you want to test how the PDF looks, change the PRINT_API_URL environment variable to something you control (for example https://webhook.site)."
                }
            ),
            200,
        )

    try:
        r = requests.post(
            f"{PRINT_API_URL}/api/jobs",
            headers={"X-API-Key": PRINT_API_KEY},
            data={"card_id": card_id},
            files={"pdf": pdf_file.stream},
            timeout=10,
        )
        return r.text, r.status_code
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(debug=True)
