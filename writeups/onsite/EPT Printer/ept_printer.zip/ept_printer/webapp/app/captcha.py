import requests
from flask import current_app


def verify_turnstile(captcha_response, remote_ip):
    print(
        f"Verifying turnstile for remote IP {remote_ip} and response: {captcha_response}"
    )
    secret_key = current_app.config.get("TURNSTILE_SECRET_KEY")
    captcha_verification_url = (
        "https://challenges.cloudflare.com/turnstile/v0/siteverify"
    )
    data = {"secret": secret_key, "response": captcha_response, "remoteip": remote_ip}
    captcha_verification = requests.post(
        captcha_verification_url, data=data, timeout=10
    ).json()
    print(f"Checking turnstile captcha response: {captcha_verification}")
    return captcha_verification.get("success", False)
