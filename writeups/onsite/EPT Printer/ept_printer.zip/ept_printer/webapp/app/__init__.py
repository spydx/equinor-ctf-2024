import logging
import os

from app.constants import IS_PRODUCTION, RoleType
from flask import Flask
from flask_login import LoginManager
from flask_sqlalchemy import SQLAlchemy
from flask_turnstile import Turnstile
from werkzeug.middleware.proxy_fix import ProxyFix

db = SQLAlchemy()


def create_app(config_filename):
    app_instance = Flask(__name__)
    if IS_PRODUCTION:
        app_instance.wsgi_app = ProxyFix(
            app_instance.wsgi_app, x_for=1, x_host=1, x_port=1
        )
        app_instance.config["TURNSTILE_SITEKEY"] = os.getenv("TURNSTILE_SITEKEY")
        app_instance.config["TURNSTILE_SECRET_KEY"] = os.getenv("TURNSTILE_SECRET_KEY")
        turnstile = Turnstile()
        turnstile.init_app(app_instance)
    app_instance.config.from_object(config_filename)

    gunicorn_logger = logging.getLogger("gunicorn.error")
    app_instance.logger.handlers = gunicorn_logger.handlers
    app_instance.logger.setLevel(gunicorn_logger.level)

    # Database stuffs
    db.init_app(app_instance)
    import app.models.approval
    import app.models.printing
    import app.models.user

    with app_instance.app_context():
        db.create_all()
        # Create an admin user
        admin_user = app.models.user.User.query.filter_by(
            username=os.getenv("ADMIN_USERNAME")
        ).first()
        if not admin_user:
            admin_user = app.models.user.User(
                username=os.getenv("ADMIN_USERNAME"),
                role=RoleType.ADMIN,
                approved=True,
                card_id="13333337",
            )
            admin_user.set_password(os.getenv("ADMIN_PASSWORD"))
            db.session.add(admin_user)
            db.session.commit()

    # Blueprints
    from app.routes.approval import bp as approval_blueprint
    from app.routes.auth import bp as auth_blueprint
    from app.routes.home import bp as home_blueprint
    from app.routes.printing import bp as printing_blueprint
    from app.routes.user import bp as user_blueprint

    app_instance.register_blueprint(auth_blueprint)
    app_instance.register_blueprint(approval_blueprint)
    app_instance.register_blueprint(home_blueprint)
    app_instance.register_blueprint(user_blueprint)
    app_instance.register_blueprint(printing_blueprint)

    # Login stuffs
    from app.models.user import User

    login_manager = LoginManager()
    login_manager.init_app(app_instance)

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(user_id)

    # Make sure we TRY to protect against dirty XSS attack
    # FIXME: remember to remove 'unsafe-inline' in script-src after testing
    script_src = "script-src 'self' 'unsafe-inline'"
    frame_src = "frame-src 'self'"
    if IS_PRODUCTION:
        script_src += " https://challenges.cloudflare.com"
        frame_src += " https://challenges.cloudflare.com"

    @app_instance.after_request
    def add_security_headers(response):
        csp_headers = [
            "default-src 'none'",
            "connect-src 'self'",
            "style-src 'self'",
            frame_src,
            script_src,
            "img-src 'self' data:",
            "font-src 'self'",
        ]
        response.headers["Content-Security-Policy"] = "; ".join(csp_headers)
        response.headers[
            "Strict-Transport-Security"
        ] = "max-age=31536000; includeSubDomains"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "SAMEORIGIN"
        return response

    return app_instance
