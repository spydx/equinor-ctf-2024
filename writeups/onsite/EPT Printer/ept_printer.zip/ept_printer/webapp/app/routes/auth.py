from app import db
from app.auth import get_auth_url, get_user_info
from app.constants import IS_PRODUCTION, MessageType, RoleType
from app.forms.login import AdminLoginForm
from app.models.user import User
from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_user, logout_user
from sqlalchemy.exc import IntegrityError

bp = Blueprint("auth", __name__)


@bp.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    form = AdminLoginForm()
    if current_user.is_authenticated:
        return redirect(url_for("printing.jobs"))
    elif request.method == "GET":
        return render_template("admin_login.html", form=form)
    elif request.method == "POST":
        if not form.validate_on_submit():
            for field, errors in form.errors.items():
                flash(f"{field}: {' '.join(errors)}", MessageType.ERROR.value)
            return render_template("admin_login.html", form=form)
        user = User.query.filter_by(username=form.username.data).first()
        if not user or not user.check_password(form.password.data):
            flash(
                "Login failed. Please check your credentials.", MessageType.ERROR.value
            )
            return render_template("admin_login.html", form=form)
        login_user(user)
        return redirect(url_for("user.profile"))


@bp.route("/login")
def login():
    if current_user.is_authenticated:
        return redirect(url_for("printing.jobs"))

    x_forwarded_host = request.headers.get("X-Forwarded-Host")

    if IS_PRODUCTION and x_forwarded_host is not None:
        x_forwarded_host = request.headers.get("X-Forwarded-Host")
        callback_url = f"https://{x_forwarded_host}/callback"
    else:
        callback_url = "http://localhost:8000/callback"

    auth_url = get_auth_url(callback_url=callback_url)
    return redirect(auth_url)


@bp.route("/callback")
def callback():

    user_uuid = request.args.get("user_uuid")
    try:
        user_info = get_user_info(user_uuid)
    except Exception as e:
        pass

    if user_info is None:
        flash(
            "Login failed. Your user does not exist in the CTF platform, how the hell did you get here?",
            MessageType.ERROR.value,
        )
        return redirect(url_for("home.index"))
    elif user_info["card_id"] is None or user_info["card_id"] == "":
        flash(
            "Login failed. Your user does not have a card ID registered to it.<br>Do note that you will only be able to solve this challenge if you are on-site.<br>If you are on-site, open a ticket in Discord.",
            MessageType.ERROR.value,
        )
        return redirect(url_for("home.index"))

    user = User.query.filter_by(username=user_info["displayname"]).first()

    if user is None:
        # We have a new user, create a user!
        user = User(
            username=user_info["displayname"],
            card_id=user_info["card_id"],
            avatar_url=user_info["avatar"],
            role=RoleType.USER,
            approved=False,
        )
        db.session.add(user)
        db.session.commit()
    else:
        if user.card_id != user_info["card_id"]:
            # Update the card ID if it's different
            user.card_id = user_info["card_id"]
            try:
                db.session.add(user)
                db.session.commit()
            except IntegrityError as e:
                db.session.rollback()
                flash(
                    f"Login failed. Tried to update card ID of user without success: {e}",
                    MessageType.ERROR.value,
                )
                return redirect(url_for("home.index"))

    login_user(user)
    return redirect(url_for("home.index"))


@bp.route("/logout")
def logout():
    logout_user()
    return redirect(url_for("home.index"))
