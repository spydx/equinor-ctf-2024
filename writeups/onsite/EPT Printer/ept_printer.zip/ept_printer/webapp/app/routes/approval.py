from datetime import datetime

from app import db
from app.constants import MessageType
from app.forms.approval import ApprovalApplicationForm, ApprovalForm
from app.models.approval import ApprovalApplication
from app.models.user import User
from flask import Blueprint, flash, render_template, request, url_for
from flask_login import current_user, login_required

bp = Blueprint("approval", __name__)


@bp.route("/applications/<application_uuid>")
@login_required
def application(application_uuid: str):
    form = ApprovalForm()
    approval_application = ApprovalApplication.query.filter_by(
        uuid=application_uuid
    ).first()
    if not approval_application:
        flash("The approval application could not be found.", MessageType.ERROR.value)
        return render_template("application.html")
    elif approval_application.user != current_user and not current_user.is_admin:
        flash(
            "You do not have permission to view this application.",
            MessageType.ERROR.value,
        )
        return render_template("application.html")
    if current_user.is_admin and not approval_application.is_reviewed:
        approval_application.is_reviewed = True
        approval_application.reviewed_at = datetime.now()
        db.session.commit()
    return render_template(
        "application.html", form=form, application=approval_application
    )


@bp.route("/applications")
@login_required
def applications():
    if current_user.is_admin:
        approval_applications = ApprovalApplication.query.all()
    else:
        approval_applications = ApprovalApplication.query.filter_by(
            user_id=current_user.id
        ).all()
    has_active_applications = any(
        [not application.is_reviewed for application in approval_applications]
    )
    if not approval_applications or not has_active_applications:
        flash(
            f'Could not find any active approval applications. You can create one <a href="{url_for("approval.apply")}">here</a>.',
            MessageType.ERROR.value,
        )
    return render_template("applications.html", applications=approval_applications)


@bp.route("/approve", methods=["POST"])
@login_required
def approve():
    form = ApprovalForm()
    if not current_user.is_admin:
        flash(
            "You do not have permission to approve applications",
            MessageType.ERROR.value,
        )
        return render_template("approve.html")
    if not form.validate_on_submit():
        for field, errors in form.errors.items():
            flash(f"{field}: {' '.join(errors)}", MessageType.ERROR.value)
        return render_template("approve.html")
    user_id = form.user_id.data
    user = User.query.filter_by(id=user_id).first()
    if not user:
        flash(f"No user with ID {user_id} could be found", MessageType.ERROR.value)
        return render_template("approve.html")
    user.approved = True
    db.session.commit()
    return render_template("approve.html", user=user)


@bp.route("/apply", methods=["GET", "POST"])
@login_required
def apply():
    form: ApprovalApplicationForm = ApprovalApplicationForm()
    approval_application: ApprovalApplication = ApprovalApplication.query.filter_by(
        user=current_user, is_reviewed=False
    ).first()
    if approval_application:
        flash(
            f'You already have an application that has not yet been reviewed and ignored by an admin.<br/>You can see its status <a href="{url_for("approval.application", application_uuid=approval_application.uuid)}">here</a>.',
            MessageType.ERROR.value,
        )
        return render_template("application_form.html", form=form, has_application=True)
    if request.method == "GET":
        return render_template(
            "application_form.html",
            form=form,
            has_application=False,
        )
    elif request.method == "POST":
        if not form.validate_on_submit():
            for field, errors in form.errors.items():
                flash(f"{field}: {' '.join(errors)}", MessageType.ERROR.value)
            return render_template("application_form.html", form=form)
        approval_application = ApprovalApplication(
            user=current_user,
            title=form.title.data,
            text=form.text.data,
        )
        db.session.add(approval_application)
        db.session.commit()
        flash(
            f'Your application has been submitted. It will be reviewed and ignored by an admin shortly.<br/>You can see its status <a href="{url_for("approval.application", application_uuid=approval_application.uuid)}">here</a>.',
            MessageType.SUCCESS.value,
        )
        return render_template("application_form.html", form=form, has_application=True)
