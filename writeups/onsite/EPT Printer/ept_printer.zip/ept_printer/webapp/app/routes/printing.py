import uuid
import traceback

from app import db
from app.captcha import verify_turnstile
from app.constants import IS_PRODUCTION, MessageType
from app.forms.printing import PrintingJobForm
from app.models.printing import PrintingJob
from app.printing.exceptions import (
    GenericPrintingError,
    LatexPrintingError,
    NotProductionError,
)
from app.printing.utils import generate_pdf, send_pdf_to_api
from flask import Blueprint, current_app, flash, render_template, request, url_for
from flask_login import current_user, login_required

bp = Blueprint("printing", __name__)


@bp.route("/jobs/<job_uuid>")
@login_required
def job(job_uuid: str):
    if not current_user.approved:
        flash(
            f'You need to be approved to view printing jobs. You can apply for an approval <a href="{url_for("approval.apply")}">here</a>.',
            MessageType.ERROR.value,
        )
        return render_template("printing_job.html", has_issue=True)
    form = PrintingJobForm()
    printing_job = PrintingJob.query.filter_by(uuid=job_uuid).first()
    if not printing_job:
        flash("The printing job could not be found.", MessageType.ERROR.value)
        return render_template("printing_job.html")
    elif printing_job.user != current_user and not current_user.is_admin:
        flash(
            "You do not have permission to view this printing job.",
            MessageType.ERROR.value,
        )
        return render_template("application.html")
    return render_template("printing_job.html", form=form, printing_job=printing_job)


@bp.route("/jobs")
@login_required
def jobs():
    if not current_user.approved:
        flash(
            f'You need to be approved to view printing jobs. You can apply for an approval <a href="{url_for("approval.apply")}">here</a>.',
            MessageType.ERROR.value,
        )
        return render_template("printing_jobs.html", has_issue=True)
    if current_user.is_admin:
        printing_jobs = PrintingJob.query.all()
    else:
        printing_jobs = PrintingJob.query.filter_by(user_id=current_user.id).all()
    if not printing_jobs:
        return render_template("printing_jobs.html")
    return render_template("printing_jobs.html", printing_jobs=printing_jobs)


@bp.route("/create", methods=["GET", "POST"])
@login_required
def form():
    if not current_user.approved:
        flash(
            f'You need to be approved to create printing jobs. You can apply for an approval <a href="{url_for("approval.apply")}">here</a>.',
            MessageType.ERROR.value,
        )
        return render_template("printing_job_form.html", has_issue=True)
    form = PrintingJobForm()
    if request.method == "GET":
        return render_template(
            "printing_job_form.html",
            form=form,
            is_production=IS_PRODUCTION,
            turnstile_sitekey=current_app.config.get("TURNSTILE_SITEKEY"),
        )
    elif request.method == "POST":
        if IS_PRODUCTION:
            try:
                captcha_response = request.form.get("cf-turnstile-response")
            except Exception as e:
                flash(
                    f"Got an error whilst checking captcha: {e}",
                    MessageType.SUCCESS.value,
                )
                return render_template(
                    "printing_job_form.html",
                    form=form,
                    is_production=IS_PRODUCTION,
                    turnstile_sitekey=current_app.config.get("TURNSTILE_SITEKEY"),
                )

            if not verify_turnstile(captcha_response, request.remote_addr):
                flash(
                    "CAPTCHA verification failed. Please try again.",
                    MessageType.ERROR.value,
                )
                return render_template(
                    "printing_job_form.html",
                    form=form,
                    is_production=IS_PRODUCTION,
                    turnstile_sitekey=current_app.config.get("TURNSTILE_SITEKEY"),
                )

        if not form.validate_on_submit():
            for field, errors in form.errors.items():
                flash(f"{field}: {' '.join(errors)}", MessageType.ERROR.value)
            return render_template(
                "printing_job_form.html",
                form=form,
                is_production=IS_PRODUCTION,
                turnstile_sitekey=current_app.config.get("TURNSTILE_SITEKEY"),
            )

        try:
            raw_pdf = generate_pdf(title=form.title.data, content=form.content.data)
        except GenericPrintingError as e:
            current_app.logger.error(
                f"Got generic printing error whilst generating PDF: {e} -> {traceback.format_exc()}"
            )
            flash(f"Got a generic printing error whilst generating the PDF: {e}", MessageType.ERROR.value)
            return render_template(
                "printing_job_form.html",
                form=form,
                is_production=IS_PRODUCTION,
                turnstile_sitekey=current_app.config.get("TURNSTILE_SITEKEY"),
            )

        except LatexPrintingError as e:
            current_app.logger.error(
                f"Got Latex printing error whilst generating PDF: {e}"
            )
            flash(
                "There was an error when generating the PDF. Scroll below to see the error.",
                MessageType.ERROR.value,
            )
            return render_template(
                "printing_job_form.html",
                form=form,
                printing_error=str(e),
                is_production=IS_PRODUCTION,
                turnstile_sitekey=current_app.config.get("TURNSTILE_SITEKEY"),
            )
        except Exception as e:
            current_app.logger.error(
                f"Got an error whilst generating the PDF: {e} -> {traceback.format_exc()}"
            )
            flash(f"Got an error whilst generating the PDF: {e}", MessageType.ERROR.value)
            return render_template(
                "printing_job_form.html",
                form=form,
                is_production=IS_PRODUCTION,
                turnstile_sitekey=current_app.config.get("TURNSTILE_SITEKEY"),
            )

        try:
            api_results = send_pdf_to_api(current_user.card_id, raw_pdf)
        except NotProductionError as e:
            # We are not running in production, we have to mock the data.
            api_results = {
                "job_uuid": str(uuid.uuid4()),
                "message": str(e),
            }
        except Exception as e:
            flash(
                f"There was an issue with sending the PDF to the printer:<br><br><pre class='api-error-message'>{str(e)}</pre>",
                MessageType.ERROR.value,
            )
            return render_template(
                "printing_job_form.html",
                form=form,
                is_production=IS_PRODUCTION,
                turnstile_sitekey=current_app.config.get("TURNSTILE_SITEKEY"),
            )

        if "job_uuid" not in api_results or "message" not in api_results:
            if "message" in api_results:
                message = api_results["message"]
            else:
                message = api_results
            flash(
                f"There was an issue with sending the PDF to the printer:<br><br><pre class='api-error-message'>{message}</pre>",
                MessageType.ERROR.value,
            )
            return render_template(
                "printing_job_form.html",
                form=form,
                is_production=IS_PRODUCTION,
                turnstile_sitekey=current_app.config.get("TURNSTILE_SITEKEY"),
            )

        printing_job = PrintingJob(
            user=current_user,
            card_id=current_user.card_id,
            title=form.title.data,
            content=form.content.data,
            api_job_uuid=api_results["job_uuid"],
            api_message=api_results["message"],
        )
        db.session.add(printing_job)
        db.session.commit()

        flash(
            f'The document has been sent to the printer, the API printer job UUID is {api_results["job_uuid"]}.<br>You can view the summary <a href="{url_for("printing.job", job_uuid=printing_job.uuid)}">here</a>.',
            MessageType.SUCCESS.value,
        )
        return render_template(
            "printing_job_form.html",
            form=form,
            is_production=IS_PRODUCTION,
            turnstile_sitekey=current_app.config.get("TURNSTILE_SITEKEY"),
        )
