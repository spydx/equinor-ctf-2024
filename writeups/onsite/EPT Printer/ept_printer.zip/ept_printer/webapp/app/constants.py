import enum
import os
from pathlib import Path


class RoleType(enum.Enum):
    USER = "USER"
    ADMIN = "ADMIN"


class MessageType(enum.Enum):
    SUCCESS = "success"
    ERROR = "error"


IS_PRODUCTION = os.getenv("IS_PRODUCTION", "false").lower() == "true"
AUTH_API_PROXY_URL = os.getenv("AUTH_API_PROXY_URL", "http://auth-api-proxy:8001")
PRINT_API_PROXY_URL = os.getenv("PRINT_API_PROXY_URL", "http://print-api-proxy:8002")
PDF_TITLE_LENGTH_LIMIT = int(os.getenv("PDF_TITLE_LENGTH_LIMIT"))
PDF_CONTENT_LENGTH_LIMIT = int(os.getenv("PDF_CONTENT_LENGTH_LIMIT"))
PDF_PAGE_COUNT_LIMIT = int(os.getenv("PDF_PAGE_COUNT_LIMIT"))
PDF_FILE_SIZE_LIMIT = int(os.getenv("PDF_FILE_SIZE_LIMIT"))
LATEX_TEMPLATE = (
    (Path(__file__).parent.resolve() / "printing/template.tex").open().read()
)
LATEX_LOGO_PATH = Path(__file__).parent.resolve() / "printing/ept.png"
