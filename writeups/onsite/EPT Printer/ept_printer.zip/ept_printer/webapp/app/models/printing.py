import uuid
from datetime import datetime, timezone

from app import db
from app.constants import PDF_CONTENT_LENGTH_LIMIT, PDF_TITLE_LENGTH_LIMIT


class PrintingJob(db.Model):
    __tablename__ = "printing_jobs"

    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(
        db.String(36), nullable=False, unique=True, default=lambda: str(uuid.uuid4())
    )
    card_id = db.Column(db.String)
    title = db.Column(db.String(PDF_TITLE_LENGTH_LIMIT), nullable=False)
    content = db.Column(db.String(PDF_CONTENT_LENGTH_LIMIT), nullable=False)
    api_job_uuid = db.Column(db.String(36), nullable=False)
    api_message = db.Column(db.String(), nullable=False)
    printed_at = db.Column(db.DateTime, default=lambda: datetime.now(tz=timezone.utc))
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
