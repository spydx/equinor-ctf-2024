from app import db
from app.constants import RoleType
from flask_login import UserMixin
from werkzeug.security import check_password_hash, generate_password_hash


class User(db.Model, UserMixin):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(32), unique=True, nullable=False)
    avatar_url = db.Column(db.String, nullable=True)
    password_hash = db.Column(db.String(120), nullable=True)
    role = db.Column(db.Enum(RoleType), default=RoleType.USER)
    approved = db.Column(db.Boolean, default=False)
    card_id = db.Column(db.String)
    approval_applications = db.relationship(
        "ApprovalApplication", backref="user", lazy=True
    )
    priting_jobs = db.relationship("PrintingJob", backref="user", lazy=True)

    @property
    def is_admin(self):
        return self.role == RoleType.ADMIN

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        if self.password_hash is None:
            return False
        return check_password_hash(self.password_hash, password)
