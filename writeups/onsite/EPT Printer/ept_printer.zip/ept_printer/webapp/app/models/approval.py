import uuid

from app import db


class ApprovalApplication(db.Model):
    __tablename__ = "approval_applications"

    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(
        db.String(36), nullable=False, unique=True, default=lambda: str(uuid.uuid4())
    )
    title = db.Column(db.String(30), nullable=False)
    text = db.Column(db.String(200), nullable=False)
    is_reviewed = db.Column(db.Boolean, default=False)
    reviewed_at = db.Column(db.DateTime)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
