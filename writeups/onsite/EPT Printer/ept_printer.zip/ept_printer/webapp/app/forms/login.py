from flask_wtf import FlaskForm
from wtforms import PasswordField, StringField, SubmitField
from wtforms.validators import InputRequired, Length


class AdminLoginForm(FlaskForm):
    username = StringField(
        "Username",
        validators=[InputRequired(), Length(max=16)],
        render_kw={"placeholder": "klarz"},
    )
    password = PasswordField(
        "Password",
        validators=[InputRequired()],
        render_kw={"placeholder": "1337p4ssw0rd"},
    )
    submit = SubmitField("Login")
