from app.forms.utils import NormalizedLength, printable_only
from flask_wtf import FlaskForm
from wtforms import IntegerField, StringField, SubmitField, TextAreaField
from wtforms.validators import InputRequired, Length


class ApprovalApplicationForm(FlaskForm):
    title = StringField(
        "Application Title",
        validators=[InputRequired(), Length(max=30), printable_only],
        render_kw={"placeholder": "Some proper title..."},
    )
    text = TextAreaField(
        "Application Text",
        validators=[InputRequired(), NormalizedLength(max=200), printable_only],
        render_kw={"placeholder": "Your application text..."},
    )
    submit = SubmitField("Submit Application")


class ApprovalForm(FlaskForm):
    user_id = IntegerField(
        "User ID", validators=[InputRequired()], render_kw={"hidden": True}
    )
    submit = SubmitField("Approve User")
