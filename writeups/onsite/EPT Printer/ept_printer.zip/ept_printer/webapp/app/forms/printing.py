from app.constants import PDF_CONTENT_LENGTH_LIMIT, PDF_TITLE_LENGTH_LIMIT
from app.forms.utils import NormalizedLength, printable_only
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, TextAreaField
from wtforms.validators import InputRequired, Length


class PrintingJobForm(FlaskForm):
    title = StringField(
        "Page Title",
        validators=[InputRequired(), Length(max=PDF_TITLE_LENGTH_LIMIT), printable_only],
        render_kw={"placeholder": "Some proper document title..."},
    )
    content = TextAreaField(
        "Page Content",
        validators=[InputRequired(), NormalizedLength(max=PDF_CONTENT_LENGTH_LIMIT), printable_only],
        render_kw={"placeholder": "Contents of the document..."},
    )
    submit = SubmitField("Submit Printing Job")
