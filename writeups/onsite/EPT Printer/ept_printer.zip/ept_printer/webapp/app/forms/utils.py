import string
from wtforms.validators import ValidationError

class NormalizedLength:
    def __init__(self, max=-1):
        self.max = max

    def __call__(self, form, field):
        data = field.data.replace('\r\n', '\n')
        if len(data) > self.max:
            raise ValidationError(f'Field must be less than {self.max} characters long.')


def printable_only(form, field):
    valid_chars = string.printable
    for char in field.data:
        if char not in valid_chars:
            raise ValidationError('Field contains non-printable characters or invalid characters.')
