class PrintingApiError(Exception):
    pass


class GenericPrintingError(Exception):
    pass


class LatexPrintingError(Exception):
    pass


class NotProductionError(Exception):
    pass
