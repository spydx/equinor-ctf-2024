import re
import shutil
import subprocess
import tempfile

import requests
from app.constants import (
    LATEX_LOGO_PATH,
    LATEX_TEMPLATE,
    PDF_CONTENT_LENGTH_LIMIT,
    PDF_FILE_SIZE_LIMIT,
    PDF_PAGE_COUNT_LIMIT,
    PDF_TITLE_LENGTH_LIMIT,
    PRINT_API_PROXY_URL,
)
from app.printing.exceptions import (
    GenericPrintingError,
    LatexPrintingError,
    NotProductionError,
    PrintingApiError,
)
from pypdf import PdfReader


def generate_pdf(title, content):
    if len(title) > PDF_TITLE_LENGTH_LIMIT:
        raise GenericPrintingError(
            f"The PDF title is longer ({len(title)}) than what is allowed ({PDF_TITLE_LENGTH_LIMIT})."
        )
    elif len(content) > PDF_CONTENT_LENGTH_LIMIT:
        raise GenericPrintingError(
            f"The PDF content is longer ({len(content)}) than what is allowed ({PDF_CONTENT_LENGTH_LIMIT})."
        )
    with tempfile.TemporaryDirectory() as latex_dir:
        # Quick efficient replace in our template
        latex_content = LATEX_TEMPLATE.replace("<PRINT_JOB_TITLE>", title).replace(
            "<PRINT_JOB_CONTENT>", content
        )
        shutil.copy2(LATEX_LOGO_PATH, f"{latex_dir}/ept.png")
        latex_file = f"{latex_dir}/file.tex"
        with open(latex_file, "w") as fd:
            fd.write(latex_content)
        result = subprocess.run(
            [
                "pdflatex",
                "--no-shell-escape",
                "-interaction=nonstopmode",
                "-halt-on-error",
                "-output-directory",
                latex_dir,
                latex_file,
            ],
            timeout=5,
            capture_output=True,
            text=True,
        )
        pdf_file = f"{latex_dir}/file.pdf"
        if result.returncode != 0:
            out = result.stdout
            if "!  ==> Fatal error occurred, no output PDF file produced!" in out:
                # Note from klarz: Ignore this, it's just to hide the flag in any error output. It will not help you to solve the challenge
                pattern = r"(.*\n){2}(?=\!  ==> Fatal error occurred, no output PDF file produced!)"
                out = re.sub(pattern, "", out)
            if "EPT" in out:
                out = "Got an error, but detected EPT in the error message, ignoring error output."
            raise LatexPrintingError(out)
        reader = PdfReader(pdf_file)
        number_of_pages = len(reader.pages)
        if number_of_pages > PDF_PAGE_COUNT_LIMIT:
            raise GenericPrintingError(
                f"The PDF has more pages ({number_of_pages}) than what is allowed ({PDF_PAGE_COUNT_LIMIT})."
            )

        raw_pdf = open(pdf_file, "rb").read()
        pdf_size = len(raw_pdf)
        if pdf_size > PDF_FILE_SIZE_LIMIT:
            raise GenericPrintingError(
                f"The PDF is bigger ({pdf_size} bytes) than what is allowed ({PDF_FILE_SIZE_LIMIT} bytes)."
            )

        return raw_pdf


def send_pdf_to_api(card_id, raw_pdf):
    r = requests.post(
        f"{PRINT_API_PROXY_URL}/jobs",
        data={"card_id": card_id},
        files={"pdf": raw_pdf},
        timeout=10,
    )

    try:
        j = r.json()
    except:
        raise PrintingApiError(r.text)

    if "error" in j:
        if r.status_code == 200:
            raise NotProductionError(j["error"])
        else:
            raise PrintingApiError(j["error"])

    return j
