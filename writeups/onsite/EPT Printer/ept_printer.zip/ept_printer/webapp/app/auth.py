import requests
from app.constants import AUTH_API_PROXY_URL


def get_auth_url(callback_url):
    r = requests.post(
        f"{AUTH_API_PROXY_URL}/create",
        data={"callback_url": callback_url},
        timeout=10,
    )
    if r.status_code == 200:
        return r.json()["auth_url"]
    else:
        raise Exception(r.text)


def get_user_info(user_uuid):
    r = requests.get(
        f"{AUTH_API_PROXY_URL}/user/{user_uuid}",
        timeout=10,
    )
    if r.status_code == 200:
        return r.json()
    elif r.status_code == 404:
        return None
    else:
        raise Exception(r.text)
