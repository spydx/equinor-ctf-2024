import secrets

SQLALCHEMY_DATABASE_URI = "sqlite:///db.sqlite3"
SQLALCHEMY_TRACK_MODIFICATIONS = False
SECRET_KEY = secrets.token_urlsafe(16)
STATIC_URL_PATH = "/static"
