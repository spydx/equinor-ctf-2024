import os

import requests
from flask import Flask, jsonify, request

app = Flask(__name__)

AUTH_API_URL = os.getenv("AUTH_API_URL")


@app.route("/create", methods=["POST"])
def create_auth_url():
    if "callback_url" not in request.form:
        return jsonify({"error": "Missing callback_url"}), 400

    callback_url = request.form["callback_url"]
    if callback_url is None:
        return jsonify({"error": "callback_url is empty"}), 400

    try:
        r = requests.post(
            f"{AUTH_API_URL}/create",
            data={"callback_url": request.form["callback_url"]},
            timeout=10,
        )
        return r.text, r.status_code
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/user/<string:user_uuid>")
def user_info(user_uuid):
    try:
        r = requests.get(
            f"{AUTH_API_URL}/user/{user_uuid}",
            timeout=10,
        )
        return r.text, r.status_code
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run("0.0.0.0", port=8002, debug=True)
