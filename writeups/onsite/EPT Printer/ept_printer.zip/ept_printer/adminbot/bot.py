import os
import time

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

WEBAPP_URL = os.getenv("WEBAPP_URL", "http://webapp:8000")
APPLICATIONS_CHECK_FREQUENCY_SECONDS = int(
    os.getenv("APPLICATIONS_CHECK_FREQUENCY_SECONDS", 30)
)

while True:
    try:
        options = Options()
        options.add_argument("headless")
        options.add_argument("no-sandbox")
        options.add_argument("disable-dev-shm-usage")
        options.add_argument("disable-infobars")
        options.add_argument("disable-background-networking")
        options.add_argument("disable-default-apps")
        options.add_argument("disable-extensions")
        options.add_argument("disable-gpu")
        options.add_argument("disable-sync")
        options.add_argument("disable-translate")
        options.add_argument("hide-scrollbars")
        options.add_argument("metrics-recording-only")
        options.add_argument("mute-audio")
        options.add_argument("no-first-run")
        options.add_argument("dns-prefetch-disable")
        options.add_argument("safebrowsing-disable-auto-update")
        options.add_argument("media-cache-size=1")
        options.add_argument("disk-cache-size=1")
        browser = webdriver.Chrome(options=options)
        browser.set_page_load_timeout(5)
        browser.implicitly_wait(5)

        print("Logging into the portal")
        browser.get(f"{WEBAPP_URL}/admin/login")

        time.sleep(3)
        browser.find_element(By.ID, "username").send_keys(
            os.environ.get("ADMIN_USERNAME")
        )
        browser.find_element(By.ID, "password").send_keys(
            os.environ.get("ADMIN_PASSWORD")
        )
        browser.find_element(By.ID, "submit").click()

        print("Logged in, cookies:", browser.get_cookies())
        time.sleep(3)

        print("Fetching latest applications")
        browser.get(f"{WEBAPP_URL}/applications")
        try:
            unreviewed_application_element = browser.find_element(
                By.CLASS_NAME, "application-unreviewed"
            )
        except:
            print("Could not find any unreviewed applications")
            unreviewed_application_element = None

        if unreviewed_application_element:
            application_uuid = unreviewed_application_element.get_attribute(
                "data-application-uuid"
            )
            print(f"Visiting unreviewed application: {application_uuid}")
            browser.get(f"{WEBAPP_URL}/applications/{application_uuid}")
    except Exception as e:
        print("Got error whilst checking applications:", e)

    browser.quit()
    time.sleep(APPLICATIONS_CHECK_FREQUENCY_SECONDS)
